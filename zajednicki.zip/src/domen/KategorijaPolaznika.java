/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package domen;

import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

/**
 *
 * @author Kristina
 */
public class KategorijaPolaznika implements DomainObject{
    private int idKategorijaPolaznika;
    private String naziv;
    private String opis;

    public KategorijaPolaznika() {
    }

    public KategorijaPolaznika(int idKategorijaPolaznika, String naziv, String opis) {
        this.idKategorijaPolaznika = idKategorijaPolaznika;
        this.naziv = naziv;
        this.opis = opis;
    }

    @Override
    public String toString() {
        return naziv + " - " + opis;
    }

    public int getIdKategorijaPolaznika() {
        return idKategorijaPolaznika;
    }

    public void setIdKategorijaPolaznika(int idKategorijaPolaznika) {
        this.idKategorijaPolaznika = idKategorijaPolaznika;
    }

    public String getNaziv() {
        return naziv;
    }

    public void setNaziv(String naziv) {
        this.naziv = naziv;
    }

    public String getOpis() {
        return opis;
    }

    public void setOpis(String opis) {
        this.opis = opis;
    }

    @Override
    public String vratiUpitZaSve() {
        return "SELECT * FROM kategorijapolaznika";
    }

    @Override
    public String vratiUpitZaPretragu(String parametarPretrage) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public List<DomainObject> napraviListuSvih(ResultSet rs) throws Exception {
        List<DomainObject> lista = new ArrayList<>();
        while(rs.next()){
            int idKategorijaPolaznika = rs.getInt(1);
            String naziv = rs.getString(2);
            String opis = rs.getString(3);
            KategorijaPolaznika kategorija = new KategorijaPolaznika(idKategorijaPolaznika, naziv, opis);
            lista.add(kategorija);
        }
        return lista;
    }

    @Override
    public String vratiUpitZaInsert() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public void podesiGenerisaniId(int generisaniId) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public String vratiUpitZaUpdate() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public String vratiUpitZaDelete() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public String vratiUpitZaJednog() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public DomainObject napraviJednog(ResultSet rs) throws Exception {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

 
    
}
