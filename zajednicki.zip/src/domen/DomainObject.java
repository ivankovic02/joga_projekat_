/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package domen;

import java.io.Serializable;
import java.sql.ResultSet;
import java.util.List;

/**
 *
 * @author Kristina
 */
public interface DomainObject extends Serializable{
    
    public String vratiUpitZaSve();
    
    public String vratiUpitZaPretragu(String parametarPretrage);

    public List<DomainObject> napraviListuSvih(ResultSet rs) throws Exception;

    public String vratiUpitZaInsert(); //insertovanje

    public void podesiGenerisaniId(int generisaniId);

    public String vratiUpitZaUpdate(); //izmena

    public String vratiUpitZaDelete(); //brisanje

    public String vratiUpitZaJednog();

    public DomainObject napraviJednog(ResultSet rs) throws Exception;
}
