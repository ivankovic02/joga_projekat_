/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package domen;

import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

/**
 *
 * @author Kristina
 */
public class Polaznik implements DomainObject{
    private int idPolaznik;
    private String ime;
    private String prezime;
    private String email;
    private KategorijaPolaznika kategorijaPolaznika;

    public Polaznik() {
    }

    public Polaznik(int idPolaznik, String ime, String prezime, String email, KategorijaPolaznika kategorijaPolaznika) {
        this.idPolaznik = idPolaznik;
        this.ime = ime;
        this.prezime = prezime;
        this.email = email;
        this.kategorijaPolaznika = kategorijaPolaznika;
    }

    @Override
    public String toString() {
        return ime + " " + prezime + ", " + kategorijaPolaznika.toString();
    }

    public int getIdPolaznik() {
        return idPolaznik;
    }

    public void setIdPolaznik(int idPolaznik) {
        this.idPolaznik = idPolaznik;
    }

    public String getIme() {
        return ime;
    }

    public void setIme(String ime) {
        this.ime = ime;
    }

    public String getPrezime() {
        return prezime;
    }

    public void setPrezime(String prezime) {
        this.prezime = prezime;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public KategorijaPolaznika getKategorijaPolaznika() {
        return kategorijaPolaznika;
    }

    public void setKategorijaPolaznika(KategorijaPolaznika kategorijaPolaznika) {
        this.kategorijaPolaznika = kategorijaPolaznika;
    }

    @Override
    public String vratiUpitZaSve() {
        return "SELECT * FROM polaznik INNER JOIN kategorijapolaznika ON polaznik.idKategorijaPolaznika = kategorijapolaznika.idKategorijaPolaznika";
    }

    @Override
    public String vratiUpitZaPretragu(String parametarPretrage) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public List<DomainObject> napraviListuSvih(ResultSet rs) throws Exception {
        List<DomainObject> lista = new ArrayList<>();
        while(rs.next()){
            int idPolaznik = rs.getInt(1);
            String ime = rs.getString(2);
            String prezime = rs.getString(3);
            String email = rs.getString(4);
            int idKategorija = rs.getInt("idKategorijaPolaznika");
            String naziv = rs.getString("naziv");
            String opis = rs.getString("opis");
            KategorijaPolaznika kp = new KategorijaPolaznika(idKategorija, naziv, opis);
            Polaznik polaznik = new Polaznik(idPolaznik, ime, prezime, email, kp);
            lista.add(polaznik);
        }
        return lista;
    }

    @Override
    public String vratiUpitZaInsert() { //sacuvaj
        return "INSERT INTO polaznik(ime,prezime,email,idKategorijaPolaznika) VALUES('" + ime + "', '" + prezime + "', '" + email + "', " + kategorijaPolaznika.getIdKategorijaPolaznika() + ")";
    }

    @Override
    public void podesiGenerisaniId(int generisaniId) {
        idPolaznik = generisaniId;
    }

    @Override
    public String vratiUpitZaUpdate() { //izmeni
        return "UPDATE polaznik SET ime = '" + ime + "', prezime='" + prezime + "', email= '" + email + "', idKategorijaPolaznika='" + kategorijaPolaznika.getIdKategorijaPolaznika() + "' WHERE idPolaznik=" + idPolaznik;
    }

    @Override
    public String vratiUpitZaDelete() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public String vratiUpitZaJednog() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public DomainObject napraviJednog(ResultSet rs) throws Exception {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
}
