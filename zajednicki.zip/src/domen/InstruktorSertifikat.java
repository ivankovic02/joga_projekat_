/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package domen;

import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Objects;

/**
 *
 * @author Kristina
 */
public class InstruktorSertifikat implements DomainObject{
    
    private Instruktor instruktor;
    private Sertifikat sertifikat;
    private Date datumSticanja;

    public InstruktorSertifikat() {
    }

    public InstruktorSertifikat(Date datumSticanja, Instruktor instruktor, Sertifikat sertifikat) {
        this.datumSticanja = datumSticanja;
        this.instruktor = instruktor;
        this.sertifikat = sertifikat;
    }

    /*@Override
    public String toString() {
        return "Datum: " + datumSticanja + ", Instruktor: " + instruktor + ", Sertifikat: " + sertifikat;
    }*/

    public Date getDatumSticanja() {
        return datumSticanja;
    }

    public void setDatumSticanja(Date datumSticanja) {
        this.datumSticanja = datumSticanja;
    }

    public Instruktor getInstruktor() {
        return instruktor;
    }

    public void setInstruktor(Instruktor instruktor) {
        this.instruktor = instruktor;
    }

    public Sertifikat getSertifikat() {
        return sertifikat;
    }

    public void setSertifikat(Sertifikat sertifikat) {
        this.sertifikat = sertifikat;
    }

    @Override
    public String vratiUpitZaSve() {
        return "SELECT * FROM instruktorsertifikat JOIN instruktor ON instruktorsertifikat.idInstruktor=instruktor.idInstruktor JOIN sertifikat ON instruktorsertifikat.idSertifikat=sertifikat.idSertifikat";
    }

    @Override
    public String vratiUpitZaPretragu(String parametarPretrage) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public List<DomainObject> napraviListuSvih(ResultSet rs) throws Exception {
        List<DomainObject> lista = new ArrayList<>();
        while(rs.next()){
            Date datumSticanjaSQL = rs.getDate("datumSticanja");
            Date datumSticanjaUTIL = new java.util.Date(datumSticanjaSQL.getTime());
            int idInstruktor = rs.getInt(1);
            String ime = rs.getString("ime");
            String prezime = rs.getString("prezime");
            String brTel = rs.getString("brojTelefona");
            String email = rs.getString("email");
            String sifra = rs.getString("sifra");
            Instruktor i = new Instruktor(idInstruktor, ime, prezime, brTel, email, sifra);
            int idSertifikat = rs.getInt(2);
            String naziv = rs.getString("naziv");
            String jogaAkademija = rs.getString("jogaAkademija");
            Sertifikat s = new Sertifikat(idSertifikat, naziv, jogaAkademija);
            InstruktorSertifikat is = new InstruktorSertifikat(datumSticanjaSQL, i, s);
            lista.add(is); 
        }
        return lista;
    }

    @Override
    public String vratiUpitZaInsert() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public void podesiGenerisaniId(int generisaniId) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public String vratiUpitZaUpdate() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public String vratiUpitZaDelete() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public String vratiUpitZaJednog() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public DomainObject napraviJednog(ResultSet rs) throws Exception {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    
}
