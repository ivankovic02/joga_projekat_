/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package util;

/**
 *
 * @author Kristina
 */
public interface Operacije {
    public static final int LOGIN = 1;
    public static final int LOGOUT = 2;
    public static final int VRATI_SVE_JOGA_CASOVE = 3;
    public static final int VRATI_SVE_KATEGORIJE_POLAZNIKA = 4;
    public static final int SACUVAJ_POLAZNIKA = 5;
    public static final int IZMENI_POLAZNIKA = 6;
    public static final int VRATI_SVE_INSTRUKTORSERTIFIKAT = 7;
    public static final int KREIRAJ_POLAZNIKA = 8;
    public static final int VRATI_SVE_POLAZNIKE = 9;
}
