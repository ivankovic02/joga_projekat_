/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package so.instruktor;

import dbb.DBBroker;
import domen.Instruktor;
import java.util.List;
import so.ApstraktnaSistemskaOperacija;

/**
 *
 * @author Kristina
 */
public class SOVratiSveInstruktore extends ApstraktnaSistemskaOperacija{

    @Override
    protected void validirajPodatak(Object podatak) throws Exception {
    }

    @Override
    protected Object izvrsiOperaciju(Object podatak) throws Exception {
        return (List<Instruktor>)(List<?>) DBBroker.getInstanca().vratiSve(new Instruktor());
    }
    
}
