/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package so.priznanica;

import dbb.DBBroker;
import domen.Priznanica;
import so.ApstraktnaSistemskaOperacija;

/**
 *
 * @author Kristina
 */
public class SOPretraziPriznanicu extends ApstraktnaSistemskaOperacija{

    @Override
    protected void validirajPodatak(Object podatak) throws Exception {
        if(! (podatak instanceof Priznanica)) throw new Exception("Prosledjeni objekat nije priznanica");
    }

    @Override
    protected Object izvrsiOperaciju(Object podatak) throws Exception {
        return (Priznanica) DBBroker.getInstanca().pretraziJednog((Priznanica)podatak);
    }
    
}
