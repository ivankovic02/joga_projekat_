/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package so.priznanica;

import dbb.DBBroker;
import domen.Instruktor;
import domen.Polaznik;
import domen.Priznanica;
import java.util.List;
import so.ApstraktnaSistemskaOperacija;

/**
 *
 * @author Kristina
 */
public class SOPretraziPriznanice extends ApstraktnaSistemskaOperacija{

    @Override
    protected void validirajPodatak(Object podatak) throws Exception {
    }

    @Override
    protected Object izvrsiOperaciju(Object podatak) throws Exception {
        if(podatak instanceof Polaznik) return (List<Priznanica>)(List<?>)DBBroker.getInstanca().pretraziPoKriterijumu(new Priznanica(),(Polaznik) podatak);
        if(podatak instanceof Instruktor) return (List<Priznanica>)(List<?>)DBBroker.getInstanca().pretraziPoKriterijumu(new Priznanica(),(Instruktor) podatak);
        return (List<Priznanica>)(List<?>)DBBroker.getInstanca().pretraziPoKriterijumu(new Priznanica(),podatak);
    }
    
}
