/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package so.polaznik;

import dbb.DBBroker;
import domen.Polaznik;
import so.ApstraktnaSistemskaOperacija;

/**
 *
 * @author Kristina
 */
public class SOObrisiPolaznika extends ApstraktnaSistemskaOperacija{

    @Override
    protected void validirajPodatak(Object podatak) throws Exception {
        if(!(podatak instanceof Polaznik)) throw new Exception("Prosledjeni objekat nije tipa Polaznik");
    }

    @Override
    protected Object izvrsiOperaciju(Object podatak) throws Exception {
        DBBroker.getInstanca().obrisi((Polaznik)podatak);
        return null;
    }
    
}
