/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package so.sertifikat;

import dbb.DBBroker;
import domen.Sertifikat;
import java.util.List;
import so.ApstraktnaSistemskaOperacija;

/**
 *
 * @author Kristina
 */
public class SOUbaciSertifikat extends ApstraktnaSistemskaOperacija{

    @Override
    protected void validirajPodatak(Object podatak) throws Exception {
        if(!(podatak instanceof Sertifikat)) throw new Exception("Prosledjeni objekat nije Sertifikat");
        
        Sertifikat sertifikat = (Sertifikat) podatak;
        List<Sertifikat> lista = (List<Sertifikat>)(List<?>)DBBroker.getInstanca().vratiSve(sertifikat);
        for (Sertifikat s : lista) {
            if(s.getNaziv().equalsIgnoreCase(sertifikat.getNaziv()) && s.getJogaAkademija().equalsIgnoreCase(sertifikat.getJogaAkademija()))
                throw new Exception("Vec postoji taj sertifikat izdat od strane te joga akademije");
        }
    }

    @Override
    protected Object izvrsiOperaciju(Object podatak) throws Exception {
        DBBroker.getInstanca().kreiraj((Sertifikat)podatak);
        return null;
    }
    
}
