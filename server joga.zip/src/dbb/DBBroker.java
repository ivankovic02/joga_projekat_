/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dbb;
import domen.DomainObject;
import domen.JogaCas;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.sql.*;
import java.util.List;
import java.util.Properties;

/**
 *
 * @author Kristina
 */
public class DBBroker {
    private static DBBroker instanca;
    private Connection konekcija;

        public static DBBroker getInstanca() {
        if(instanca==null) instanca = new DBBroker();
        return instanca;
    }

    private DBBroker() {
        
    }
    
    public void otvoriKonekcijuNaBazu() throws Exception{
        //otvara konfiguracija.properties fajl
        File file = new File("konfiguracija.properties");
        FileInputStream fileInputStream = new FileInputStream(file);
        //ucitava podatke iz konfiguracija.properties fajla
        Properties properties = new Properties();
        properties.load(fileInputStream);
        
        String url = properties.getProperty("url");
        String port = properties.getProperty("port");
        String username = properties.getProperty("username");
        String password = properties.getProperty("password");
        String name = properties.getProperty("name");
        fileInputStream.close();
        konekcija = DriverManager.getConnection("jdbc:mysql://"+url+":"+port+"/"+name, username, password);
        konekcija.setAutoCommit(false);
    }
    
    public void zatvoriKonekcijuNaBazu() throws Exception{
        konekcija.close();
    }
    
    public void commit() throws Exception{
        konekcija.commit();
    }
    
    public void rollback() throws Exception{
        konekcija.rollback();
    }
    
    public List<DomainObject> vratiSve(DomainObject domainObject) throws Exception{
        String upit = domainObject.vratiUpitZaSve();
        
        PreparedStatement ps = konekcija.prepareStatement(upit);
        
        ResultSet rs = ps.executeQuery();
        
        List<DomainObject> lista = domainObject.napraviListuSvih(rs);
        
        return lista;
    }
    
    public List<DomainObject> pretraziPoKriterijumu(DomainObject domainObject, Object parametarPretrage) throws Exception{
        String upit = domainObject.vratiUpitZaPretragu(parametarPretrage);
        
        PreparedStatement ps = konekcija.prepareStatement(upit);
        
        ResultSet rs = ps.executeQuery();
        
        List<DomainObject> lista = domainObject.napraviListuSvih(rs);
        
        return lista;
    }
    
    //kreirajOdnosnoInsert
    public void kreiraj(DomainObject domainObject) throws Exception{
        String upit = domainObject.vratiUpitZaInsert();
        
        PreparedStatement ps = konekcija.prepareStatement(upit, Statement.RETURN_GENERATED_KEYS);
        
        ps.execute();
        
        ResultSet rs = ps.getGeneratedKeys();
        if(rs.next()){
            int generisaniId = rs.getInt(1);
            domainObject.podesiGenerisaniId(generisaniId);
        }
    }
    
    //zapamtiOdnosnoUpdate
    public void zapamti(DomainObject domainObject) throws Exception{
        String upit = domainObject.vratiUpitZaUpdate();
        
        PreparedStatement ps = konekcija.prepareStatement(upit);
        
        ps.execute();
    }
    
    public void obrisi(DomainObject domainObject) throws Exception{
        String upit = domainObject.vratiUpitZaDelete();
        
        PreparedStatement ps = konekcija.prepareStatement(upit);
        
        ps.execute();
    }
    
    public DomainObject pretraziJednog(DomainObject domainObject) throws Exception{
        String upit = domainObject.vratiUpitZaJednog();
        
        PreparedStatement ps = konekcija.prepareStatement(upit);
        
        ResultSet rs = ps.executeQuery();
        
        DomainObject rezultat = domainObject.napraviJednog(rs);
        
        return rezultat;
    }
    
}
