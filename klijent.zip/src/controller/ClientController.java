/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controller;

import domen.Instruktor;
import domen.InstruktorSertifikat;
import domen.JogaCas;
import domen.KategorijaPolaznika;
import domen.Polaznik;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;
import java.util.List;
import util.Odgovor;
import util.Operacije;
import util.Zahtev;

/**
 *
 * @author Kristina
 */
public class ClientController {
    private static ClientController instanca;
    private Socket socket;
    private Instruktor ulogovani;

    public ClientController() throws Exception {
        socket = new Socket("localhost", 10000);
    }
    
    public static ClientController getInstanca() throws Exception {
        if(instanca == null) instanca = new ClientController();
        return instanca;
    }

    public Instruktor getUlogovani() {
        return ulogovani;
    }

    public void setUlogovani(Instruktor ulogovani) {
        this.ulogovani = ulogovani;
    }
    
    public Object posaljiZahtev(int operacija, Object podatak) throws Exception{
        Zahtev zahtev = new Zahtev(operacija, podatak);
        ObjectOutputStream out = new ObjectOutputStream(socket.getOutputStream());
        out.writeObject(zahtev);
        ObjectInputStream in = new ObjectInputStream(socket.getInputStream());
        Odgovor odgovor = (Odgovor) in.readObject();
        if(odgovor.getGreska()!=null) throw odgovor.getGreska();
        return odgovor.getPodatak();
    }

    public Instruktor login(Instruktor instruktor) throws Exception {
        return (Instruktor) posaljiZahtev(Operacije.LOGIN, instruktor);
    }

    public List<JogaCas> vratiSveJogaCasove() throws Exception {
        return (List<JogaCas>) posaljiZahtev(Operacije.VRATI_SVE_JOGA_CASOVE, null);
    }
    
    public List<KategorijaPolaznika> vratiSveKategorijePolaznika() throws Exception {
        return (List<KategorijaPolaznika>) posaljiZahtev(Operacije.VRATI_SVE_KATEGORIJE_POLAZNIKA, null);
    }

    public void izmeniPolaznika(Polaznik polaznik) throws Exception {
        posaljiZahtev(Operacije.IZMENI_POLAZNIKA, polaznik);
    }

    public void sacuvajPolaznika(Polaznik polaznik) throws Exception {
        posaljiZahtev(Operacije.SACUVAJ_POLAZNIKA, polaznik);
    }

    public List<InstruktorSertifikat> vratiSveInstruktorSertifikat() throws Exception {
        return (List<InstruktorSertifikat>) posaljiZahtev(Operacije.VRATI_SVE_INSTRUKTORSERTIFIKAT, null);
    }

    public Polaznik kreirajPolaznika() throws Exception {
        return (Polaznik) posaljiZahtev(Operacije.KREIRAJ_POLAZNIKA, null);
    }

    public List<Polaznik> vratiSvePolaznike() throws Exception {
        return (List<Polaznik>) posaljiZahtev(Operacije.VRATI_SVE_POLAZNIKE, null);
    }
}
