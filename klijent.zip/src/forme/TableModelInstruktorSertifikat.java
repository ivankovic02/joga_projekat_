/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package forme;

import controller.ClientController;
import domen.InstruktorSertifikat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import javax.swing.table.AbstractTableModel;

/**
 *
 * @author Kristina
 */
public class TableModelInstruktorSertifikat extends AbstractTableModel implements Runnable{
    List<InstruktorSertifikat> lista = new ArrayList<>();
    String[] kolone = new String[]{"Instruktor","Sertifikat","Datum sticanja"};

    public TableModelInstruktorSertifikat(List<InstruktorSertifikat> lista) {
        this.lista = lista;
    }
    

    @Override
    public int getRowCount() {
        return lista.size();
    }

    @Override
    public int getColumnCount() {
        return kolone.length;
    }

    @Override
    public Object getValueAt(int rowIndex, int columnIndex) {
        InstruktorSertifikat is = lista.get(rowIndex);
        switch(columnIndex){
            case 0:
                return is.getInstruktor();
            case 1:
                return is.getSertifikat();
            case 2: 
                SimpleDateFormat sdf = new SimpleDateFormat("dd.MM.yyyy");
                String datumSticanja = sdf.format(is.getDatumSticanja());
                return datumSticanja;
            default:
                return "";
        }
    }

    @Override
    public String getColumnName(int column) {
        return kolone[column];
    }

    @Override
    public void run() {
          try {
            while(true){
                Thread.sleep(3000);
                lista = ClientController.getInstanca().vratiSveInstruktorSertifikat();
                fireTableDataChanged();
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }
    
    
    
}
