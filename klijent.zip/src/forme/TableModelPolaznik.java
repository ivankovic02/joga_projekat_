/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package forme;

import domen.Polaznik;
import java.util.ArrayList;
import java.util.List;
import javax.swing.table.AbstractTableModel;

/**
 *
 * @author Kristina
 */
public class TableModelPolaznik extends AbstractTableModel{
    
    private List<Polaznik> lista = new ArrayList<>();
    private String[] kolone = new String[]{"Ime","Prezime","Email","Kategorija polaznika","Popust"};

    public TableModelPolaznik(List<Polaznik> lista) {
        this.lista = lista;
    }

    @Override
    public int getRowCount() {
        return lista.size();
    }

    @Override
    public int getColumnCount() {
        return kolone.length;
    }

    @Override
    public Object getValueAt(int rowIndex, int columnIndex) {
        Polaznik p = lista.get(rowIndex);
        switch(columnIndex){
            case 0:
                return p.getIme();
            case 1:
                return p.getPrezime();
            case 2:
                return p.getEmail();
            case 3:
                return p.getKategorijaPolaznika().getNaziv();
            case 4:
                return p.getKategorijaPolaznika().getOpis();
            default:
                return "";
        }
    }

    @Override
    public String getColumnName(int column) {
        return kolone[column];
    }
    
}
