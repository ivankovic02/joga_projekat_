/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package so.priznanica;

import dbb.DBBroker;
import domen.Instruktor;
import domen.KategorijaPolaznika;
import domen.Polaznik;
import domen.Priznanica;
import java.util.ArrayList;
import java.util.Date;
import so.ApstraktnaSistemskaOperacija;

/**
 *
 * @author Kristina
 */
public class SOKreirajPriznanicu extends ApstraktnaSistemskaOperacija{

    @Override
    protected void validirajPodatak(Object podatak) throws Exception {
    }

    @Override
    protected Object izvrsiOperaciju(Object podatak) throws Exception {
        
        Priznanica priznanica = new Priznanica();
        
        priznanica.setDatumIzdavanja(new Date());
        priznanica.setPopust(0);
        priznanica.setUkupanIznos(0);
        Instruktor instruktor = new Instruktor(1, "", "", "", "", "");
        KategorijaPolaznika kategorijaPolaznika = new KategorijaPolaznika(1, "", "");
        Polaznik polaznik = new Polaznik(1, "", "", "", kategorijaPolaznika);
        priznanica.setInstruktor(instruktor);
        priznanica.setPolaznik(polaznik);
        priznanica.setListaStavki(new ArrayList<>());
        
        DBBroker.getInstanca().kreiraj(priznanica);
        
        return priznanica;
    }
    
}
