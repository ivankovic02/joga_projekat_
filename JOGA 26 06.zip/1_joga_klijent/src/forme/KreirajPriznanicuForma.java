/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package forme;

import controller.ClientController;
import domen.JogaCas;
import domen.KategorijaPolaznika;
import domen.Polaznik;
import domen.Priznanica;
import domen.StavkaPriznanice;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.LinkedList;
import java.util.List;
import javax.swing.JOptionPane;

/**
 *
 * @author Kristina
 */
public class KreirajPriznanicuForma extends javax.swing.JFrame {
    private Priznanica priznanica;
    private TableModelStavkePriznanice tblModelStavkePriznanice;

    /**
     * Creates new form NovaPriznanicaForma
     */
    public KreirajPriznanicuForma(Priznanica priznanica) {
        initComponents();
        setLocationRelativeTo(null);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        setTitle("KREIRAJ PRIZNANICU");
        
        this.priznanica = priznanica;
        
        try {
            if( txtCenaCasa.getText().isEmpty() || txtIznosStavke.getText().isEmpty() )
                btnIzracunajUkupanIznosPriznanice.setEnabled(false);
         
            List<Polaznik> polaznici = ClientController.getInstanca().vratiSvePolaznike();
            for (Polaznik polaznik : polaznici) {
                cmbPolaznik.addItem(polaznik);
            }
            cmbPolaznikActionPerformed(null);
            
            List<JogaCas> jogaCasovi = ClientController.getInstanca().vratiSveJogaCasove();
            for (JogaCas jogaCas : jogaCasovi) {
                cmbJogaCas.addItem(jogaCas);
            }
            cmbJogaCasActionPerformed(null);
            
            JogaCas jogaCas = (JogaCas) cmbJogaCas.getSelectedItem();
            txtCenaCasa.setText(jogaCas.getCena() + "");
            if (! txtCenaCasa.getText().isEmpty() && ! txtBrojCasova.getText().isEmpty() ) {
                int iznosStavkeInteger = Integer.parseInt(txtCenaCasa.getText()) * Integer.parseInt(txtBrojCasova.getText());
                txtIznosStavke.setText(iznosStavkeInteger + "");
                btnIzracunajUkupanIznosPriznanice.setEnabled(true);
            }
            
            tblModelStavkePriznanice = new TableModelStavkePriznanice(new ArrayList<>());
            tblStavkePriznanice.setModel(tblModelStavkePriznanice);
            

            //popunjavanje potpuno nove prethodno kreirane priznanice popunjene samo difolt vreddnostima
            
            if ( priznanica.getPolaznik().getIme().isEmpty() ) {
                Date danasnjiDatum = new Date();
                SimpleDateFormat sdf = new SimpleDateFormat("dd.MM.yyyy");
                txtDatumIzdavanja.setText(sdf.format(danasnjiDatum));

                /*Polaznik polaznik = (Polaznik) cmbPolaznik.getSelectedItem();
                String kategorija = polaznik.getKategorijaPolaznika().getNaziv();
                if (kategorija.equals("Pocetnik")) {
                    txtPopust.setText("10");
                }
                if (kategorija.equals("Dete")) {
                    txtPopust.setText("15");
                }
                if (kategorija.equals("Srednji nivo")) {
                    txtPopust.setText("0");
                }
                if (kategorija.equals("Napredni nivo")) {
                    txtPopust.setText("0");
                }
                if (kategorija.equals("Senior")) {
                    txtPopust.setText("8");
                }
                if (kategorija.equals("Trudnica")) {
                    txtPopust.setText("12");
                }*/
                
            //promena vec postojece priznanice sa vrednostima
              } else if (! priznanica.getPolaznik().getIme().isEmpty() ) {
                cmbPolaznik.setSelectedItem(priznanica.getPolaznik());
                cmbPolaznik.setEnabled(false);
                /*int trazeniId = priznanica.getPolaznik().getIdPolaznik();
                for (int i = 0; i < cmbPolaznik.getItemCount(); i++) {
                    Polaznik polaznik = (Polaznik) cmbPolaznik.getItemAt(i);
                    if (polaznik != null && polaznik.getIdPolaznik()==trazeniId) {
                        cmbPolaznik.setSelectedIndex(i);
                        break;
                    }
                }
                cmbPolaznik.setEnabled(false);*/
                txtPopust.setText(priznanica.getPopust()+"");
                Date danasnjiDatum = new Date();
                SimpleDateFormat sdf = new SimpleDateFormat("dd.MM.yyyy");
                txtDatumIzdavanja.setText(sdf.format(danasnjiDatum));
                txtUkupanIznos.setText(priznanica.getUkupanIznos()+"rsd");
                tblModelStavkePriznanice.setLista(priznanica.getListaStavki());
            }
            
        } catch (Exception ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(rootPane, ex.getMessage());
        }
        
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        btnZapamtiPriznanicu = new javax.swing.JButton();
        cmbPolaznik = new javax.swing.JComboBox<>();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        txtDatumIzdavanja = new javax.swing.JFormattedTextField();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        btnIzracunajUkupanIznosPriznanice = new javax.swing.JButton();
        txtPopust = new javax.swing.JTextField();
        txtUkupanIznos = new javax.swing.JTextField();
        jScrollPane1 = new javax.swing.JScrollPane();
        tblStavkePriznanice = new javax.swing.JTable();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        cmbJogaCas = new javax.swing.JComboBox<>();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        txtDatumPocetka = new javax.swing.JFormattedTextField();
        txtDatumZavrsetka = new javax.swing.JFormattedTextField();
        jLabel9 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        txtBrojCasova = new javax.swing.JTextField();
        jLabel11 = new javax.swing.JLabel();
        txtCenaCasa = new javax.swing.JTextField();
        txtIznosStavke = new javax.swing.JTextField();
        jLabel12 = new javax.swing.JLabel();
        jLabel13 = new javax.swing.JLabel();
        jScrollPane2 = new javax.swing.JScrollPane();
        txtAreaNapomene = new javax.swing.JTextArea();
        btnDodajStavku = new javax.swing.JButton();
        btnObrisiStavku = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        btnZapamtiPriznanicu.setText("ZAPAMTI PRIZNANICU");

        cmbPolaznik.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cmbPolaznikActionPerformed(evt);
            }
        });

        jLabel1.setText("Polaznik");

        jLabel2.setText("Datum izdavanja");

        txtDatumIzdavanja.setEditable(false);
        txtDatumIzdavanja.setBackground(new java.awt.Color(255, 204, 255));
        txtDatumIzdavanja.setFormatterFactory(new javax.swing.text.DefaultFormatterFactory(new javax.swing.text.DateFormatter(new java.text.SimpleDateFormat("dd.MM.yyyy"))));

        jLabel3.setText("Popust u %");

        jLabel4.setText("Ukupan iznos (sa popustom)");

        btnIzracunajUkupanIznosPriznanice.setText("Izracunaj ukupan iznos");
        btnIzracunajUkupanIznosPriznanice.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnIzracunajUkupanIznosPriznaniceActionPerformed(evt);
            }
        });

        txtPopust.setEditable(false);
        txtPopust.setBackground(new java.awt.Color(255, 204, 255));

        txtUkupanIznos.setEditable(false);
        txtUkupanIznos.setBackground(new java.awt.Color(255, 204, 255));

        tblStavkePriznanice.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane1.setViewportView(tblStavkePriznanice);

        jLabel5.setText("Stavke priznanice");

        jLabel6.setText("Joga cas");

        cmbJogaCas.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cmbJogaCasActionPerformed(evt);
            }
        });

        jLabel7.setText("Datum pocetka");

        jLabel8.setText("Datum zavrsetka");

        txtDatumPocetka.setFormatterFactory(new javax.swing.text.DefaultFormatterFactory(new javax.swing.text.DateFormatter(new java.text.SimpleDateFormat("dd.MM.yyyy"))));

        txtDatumZavrsetka.setFormatterFactory(new javax.swing.text.DefaultFormatterFactory(new javax.swing.text.DateFormatter(new java.text.SimpleDateFormat("dd.MM.yyyy"))));

        jLabel9.setText("Priznanica");

        jLabel10.setText("Broj casova");

        jLabel11.setText("Cena casa");

        txtCenaCasa.setEditable(false);
        txtCenaCasa.setBackground(new java.awt.Color(255, 204, 255));

        txtIznosStavke.setEditable(false);
        txtIznosStavke.setBackground(new java.awt.Color(255, 204, 255));

        jLabel12.setText("Iznos stavke");

        jLabel13.setText("Napomene");

        txtAreaNapomene.setColumns(20);
        txtAreaNapomene.setRows(5);
        jScrollPane2.setViewportView(txtAreaNapomene);

        btnDodajStavku.setText("DODAJ STAVKU");

        btnObrisiStavku.setText("OBRISI STAVKU");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addContainerGap()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jLabel4)
                                .addGap(18, 18, 18)
                                .addComponent(txtUkupanIznos)
                                .addGap(18, 18, 18)
                                .addComponent(btnIzracunajUkupanIznosPriznanice))
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jLabel2)
                                .addGap(18, 18, 18)
                                .addComponent(txtDatumIzdavanja))
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 70, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(txtPopust, javax.swing.GroupLayout.PREFERRED_SIZE, 45, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(0, 0, Short.MAX_VALUE))
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jLabel1)
                                .addGap(64, 64, 64)
                                .addComponent(cmbPolaznik, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                            .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 515, Short.MAX_VALUE)))
                    .addGroup(layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jLabel6)
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addGap(85, 85, 85)
                        .addComponent(cmbJogaCas, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                .addContainerGap())
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addComponent(jLabel5)
                .addGap(213, 213, 213))
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel10)
                                    .addComponent(jLabel11)
                                    .addComponent(jLabel12))
                                .addGap(18, 18, 18)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(txtBrojCasova)
                                    .addComponent(txtCenaCasa)
                                    .addComponent(txtIznosStavke)))
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel7)
                                    .addComponent(jLabel8)
                                    .addComponent(jLabel13))
                                .addGap(18, 18, 18)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(txtDatumZavrsetka)
                                    .addComponent(txtDatumPocetka)
                                    .addComponent(jScrollPane2)))
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(btnObrisiStavku)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(btnDodajStavku)))
                        .addContainerGap())
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                .addComponent(jLabel9)
                                .addGap(232, 232, 232))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                .addComponent(btnZapamtiPriznanicu)
                                .addGap(182, 182, 182))))))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addComponent(jLabel9)
                .addGap(17, 17, 17)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(cmbPolaznik, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel1))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2)
                    .addComponent(txtDatumIzdavanja, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(22, 22, 22)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel3)
                    .addComponent(txtPopust, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel4)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(txtUkupanIznos, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(btnIzracunajUkupanIznosPriznanice)))
                .addGap(39, 39, 39)
                .addComponent(jLabel5)
                .addGap(10, 10, 10)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel6)
                    .addComponent(cmbJogaCas, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel10)
                    .addComponent(txtBrojCasova, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel11)
                    .addComponent(txtCenaCasa, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txtIznosStavke, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel12))
                .addGap(11, 11, 11)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel7)
                    .addComponent(txtDatumPocetka, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel8)
                    .addComponent(txtDatumZavrsetka, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel13)
                    .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(23, 23, 23)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnDodajStavku)
                    .addComponent(btnObrisiStavku))
                .addGap(18, 18, 18)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 132, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(btnZapamtiPriznanicu)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnIzracunajUkupanIznosPriznaniceActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnIzracunajUkupanIznosPriznaniceActionPerformed
        // TODO add your handling code here:
        try {
            
        } catch (Exception ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(rootPane, ex.getMessage());
        }
    }//GEN-LAST:event_btnIzracunajUkupanIznosPriznaniceActionPerformed

    private void cmbJogaCasActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cmbJogaCasActionPerformed
        // TODO add your handling code here:
        try {
            JogaCas selektovaniCas = (JogaCas) cmbJogaCas.getSelectedItem();
            txtCenaCasa.setText(String.valueOf(selektovaniCas.getCena()));

            if (!txtBrojCasova.getText().isEmpty()) {
                int brojCasova = Integer.parseInt(txtBrojCasova.getText());
                int cenaCasa = selektovaniCas.getCena();
                txtIznosStavke.setText(String.valueOf(brojCasova * cenaCasa));
            }

        } catch (Exception ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(rootPane, ex.getMessage());
        }
    }//GEN-LAST:event_cmbJogaCasActionPerformed

    private void cmbPolaznikActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cmbPolaznikActionPerformed
        // TODO add your handling code here:
        try {
            Polaznik polaznik = (Polaznik) cmbPolaznik.getSelectedItem();

            String kategorija = polaznik.getKategorijaPolaznika().getNaziv();

            if (kategorija.equals("Pocetnik")) {
                txtPopust.setText("10");
            }
            if (kategorija.equals("Dete")) {
                txtPopust.setText("15");
            }
            if (kategorija.equals("Srednji nivo")) {
                txtPopust.setText("0");
            }
            if (kategorija.equals("Napredni nivo")) {
                txtPopust.setText("0");
            }
            if (kategorija.equals("Senior")) {
                txtPopust.setText("8");
            }
            if (kategorija.equals("Trudnica")) {
                txtPopust.setText("12");
            }

        } catch (Exception ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(rootPane, ex.getMessage());
        }
    }//GEN-LAST:event_cmbPolaznikActionPerformed

    /**
     * @param args the command line arguments
     */
    

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnDodajStavku;
    private javax.swing.JButton btnIzracunajUkupanIznosPriznanice;
    private javax.swing.JButton btnObrisiStavku;
    private javax.swing.JButton btnZapamtiPriznanicu;
    private javax.swing.JComboBox<Object> cmbJogaCas;
    private javax.swing.JComboBox<Object> cmbPolaznik;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JTable tblStavkePriznanice;
    private javax.swing.JTextArea txtAreaNapomene;
    private javax.swing.JTextField txtBrojCasova;
    private javax.swing.JTextField txtCenaCasa;
    private javax.swing.JFormattedTextField txtDatumIzdavanja;
    private javax.swing.JFormattedTextField txtDatumPocetka;
    private javax.swing.JFormattedTextField txtDatumZavrsetka;
    private javax.swing.JTextField txtIznosStavke;
    private javax.swing.JTextField txtPopust;
    private javax.swing.JTextField txtUkupanIznos;
    // End of variables declaration//GEN-END:variables
}
