/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package domen;

import java.sql.ResultSet;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Kristina
 */
public class Priznanica implements DomainObject{
    
    private int idPriznanica;
    private Date datumIzdavanja;
    private int popust; // broj od 0 do 100, jer je u procentima iskazan podatak
    private int ukupanIznos; //iznos SA POPUSTOM <- suma iznosa svih stavki * (1-popust/100))
    private Instruktor instruktor;
    private Polaznik polaznik;
    private List<StavkaPriznanice> listaStavki;

    public Priznanica(int idPriznanica, Date datumIzdavanja, int popust, int ukupanIznos, Instruktor instruktor, Polaznik polaznik, List<StavkaPriznanice> listaStavki) {
        this.idPriznanica = idPriznanica;
        this.datumIzdavanja = datumIzdavanja;
        this.popust = popust;
        this.ukupanIznos = ukupanIznos;
        this.instruktor = instruktor;
        this.polaznik = polaznik;
        this.listaStavki = listaStavki;
    }
    
    public Priznanica() {
    }

    @Override
    public String vratiUpitZaSve() {
        return "SELECT * FROM priznanica JOIN instruktor ON priznanica.idInstruktor=instruktor.idInstruktor JOIN polaznik ON priznanica.idPolaznik=polaznik.idPolaznik JOIN kategorijaPolaznika ON polaznik.idKategorijaPolaznika=kategorijaPolaznika.idKategorijaPolaznika";
    }

    @Override
    public String vratiUpitZaPretragu(Object parametarPretrage) {
        if (parametarPretrage instanceof java.util.Date) {
            Date datumUTIL = (java.util.Date) parametarPretrage;
            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
            String formatiranDatum = sdf.format(datumUTIL);
            //Date datumSQL = new java.sql.Date(datumUTIL.getTime());
            return "SELECT * FROM priznanica JOIN instruktor ON priznanica.idInstruktor=instruktor.idInstruktor JOIN polaznik ON priznanica.idPolaznik=polaznik.idPolaznik JOIN kategorijaPolaznika ON polaznik.idKategorijaPolaznika=kategorijaPolaznika.idKategorijaPolaznika WHERE datumIzdavanja = '" + formatiranDatum + "'";
        } else if(parametarPretrage instanceof Instruktor){
            return "SELECT * FROM priznanica JOIN instruktor ON priznanica.idInstruktor=instruktor.idInstruktor JOIN polaznik ON priznanica.idPolaznik=polaznik.idPolaznik JOIN kategorijaPolaznika ON polaznik.idKategorijaPolaznika=kategorijaPolaznika.idKategorijaPolaznika WHERE priznanica.idInstruktor = '" + ((Instruktor) parametarPretrage).getIdInstruktor() + "'";
        }else if(parametarPretrage instanceof Polaznik){
            return "SELECT * FROM priznanica JOIN instruktor ON priznanica.idInstruktor=instruktor.idInstruktor JOIN polaznik ON priznanica.idPolaznik=polaznik.idPolaznik JOIN kategorijaPolaznika ON polaznik.idKategorijaPolaznika=kategorijaPolaznika.idKategorijaPolaznika WHERE priznanica.idPolaznik = '" + ((Polaznik) parametarPretrage).getIdPolaznik() + "'";
        }
        return null;
    }

    @Override
    public List<DomainObject> napraviListuSvih(ResultSet rs) throws Exception {
        List<DomainObject> lista = new ArrayList<>();
        while(rs.next()){
            int idPriznanica = rs.getInt(1);
            Date datumIzdavanjaSQL = rs.getDate("datumIzdavanja");
            Date datumIzdavanjaUTIL = new java.util.Date(datumIzdavanjaSQL.getTime());
            int popust = rs.getInt("popust");
            int ukupanIznos = rs.getInt("ukupanIznos");
            
            int idPolaznik = rs.getInt("idPolaznik");
            String ime = rs.getString("polaznik.ime");
            String prezime = rs.getString("polaznik.prezime");
            String email = rs.getString("polaznik.email");
            int idKategorijaPolaznika = rs.getInt("idKategorijaPolaznika");
            String naziv = rs.getString("naziv");
            String opis = rs.getString("opis");
            KategorijaPolaznika kategorija = new KategorijaPolaznika(idKategorijaPolaznika, naziv, opis);
            Polaznik polaznik = new Polaznik(idPolaznik, ime, prezime, email, kategorija);
            
            int idInstruktor = rs.getInt("idInstruktor");
            String ime1 = rs.getString("instruktor.ime");
            String prezime1 = rs.getString("instruktor.prezime");
            String brojTel = rs.getString("instruktor.brojTelefona");
            String email1 = rs.getString("instruktor.email");
            String sifra = rs.getString("instruktor.sifra");
            Instruktor instruktor = new Instruktor(idInstruktor, ime1, prezime1, brojTel, email1, sifra);
            
            Priznanica priznanica = new Priznanica(idPriznanica, datumIzdavanjaUTIL, popust, ukupanIznos, instruktor, polaznik, new ArrayList<>());
            lista.add(priznanica);
        }
        return lista;
    }

    @Override
    public String vratiUpitZaInsert() {
        Date datumIzdavanja = this.datumIzdavanja;
        Date datumIzdavanjaSQL = new java.sql.Date(datumIzdavanja.getTime());
        return "INSERT INTO priznanica(datumIzdavanja,popust,ukupanIznos,idInstruktor,idPolaznik) VALUES('" + datumIzdavanjaSQL + "','" + popust + "','" + ukupanIznos + "','" + instruktor.getIdInstruktor() + "','" + polaznik.getIdPolaznik() + "')";
    }

    @Override
    public void podesiGenerisaniId(int generisaniId) {
        idPriznanica = generisaniId;
    }

    @Override
    public String vratiUpitZaUpdate() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public String vratiUpitZaDelete() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public String vratiUpitZaJednog() {
        return "SELECT * FROM priznanica JOIN instruktor ON priznanica.idInstruktor=instruktor.idInstruktor JOIN polaznik ON priznanica.idPolaznik=polaznik.idPolaznik JOIN kategorijaPolaznika ON polaznik.idKategorijaPolaznika=kategorijaPolaznika.idKategorijaPolaznika JOIN stavkapriznanice ON priznanica.idPriznanica=stavkapriznanice.idPriznanica JOIN jogacas ON jogacas.idJogaCas=stavkapriznanice.idJogaCas WHERE priznanica.idPriznanica = " + idPriznanica ;
    }

    @Override
    public DomainObject napraviJednog(ResultSet rs) throws Exception {
        Priznanica priznanica = null;
        while (rs.next()) {
            
            if (priznanica == null) {
                int idInstruktor = rs.getInt("idInstruktor");
                String ime = rs.getString("instruktor.ime");
                String prezime = rs.getString("instruktor.prezime");
                String brojTel = rs.getString("instruktor.brojTelefona");
                String email = rs.getString("instruktor.email");
                String sifra = rs.getString("instruktor.sifra");
                Instruktor instruktor = new Instruktor(idInstruktor, ime, prezime, brojTel, email, sifra);

                int idPolaznik = rs.getInt("idPolaznik");
                String ime1 = rs.getString("polaznik.ime");
                String prezime1 = rs.getString("polaznik.prezime");
                String email1 = rs.getString("polaznik.email");
                int idKategorijaPolaznika = rs.getInt("idKategorijaPolaznika");
                String naziv = rs.getString("kategorijapolaznika.naziv");
                String opis = rs.getString("kategorijapolaznika.opis");
                KategorijaPolaznika kategorijaPolaznika = new KategorijaPolaznika(idKategorijaPolaznika, naziv, opis);
                Polaznik polaznik = new Polaznik(idPolaznik, ime, prezime, email, kategorijaPolaznika);
                
                int idPriznanica = rs.getInt("idPriznanica");
                int popust = rs.getInt("popust");
                int ukupanIznosPriznanice = rs.getInt("priznanica.ukupanIznos");
                Date datumIzdavanjaSQL = rs.getDate("datumIzdavanja");
                Date datumIzdavanjaUTIL = new java.util.Date(datumIzdavanjaSQL.getTime());
                
                priznanica = new Priznanica(idPriznanica, datumIzdavanjaUTIL, popust, ukupanIznosPriznanice, instruktor, polaznik, new ArrayList<>());
            }
            
            int idJogaCas = rs.getInt("idJogaCas");
            String opis1 = rs.getString("opisCasa");
            int trajanje = rs.getInt("trajanje");
            int cena = rs.getInt("jogacas.cena");
            JogaCas jogaCas = new JogaCas(idJogaCas, opis1, trajanje, cena);
            
            int rb = rs.getInt("rb");
            int brojCasova = rs.getInt("brojCasova");
            int cena1 = rs.getInt("stavkapriznanice.cena");
            int iznosStavke = rs.getInt("iznosStavke");
            Date datumPocetkaSQL = rs.getDate("datumPocetka");
            Date datumPocetkaUTIL = new java.util.Date(datumPocetkaSQL.getTime());
            Date datumZavrsetkaSQL = rs.getDate("datumZavrsetka");
            Date datumZavrsetkaUTIL = new java.util.Date(datumZavrsetkaSQL.getTime());
            String napomene = rs.getString("napomene");
            StavkaPriznanice stavkaPriznanice = new StavkaPriznanice(priznanica, rb, brojCasova, cena1, iznosStavke, datumPocetkaUTIL, datumZavrsetkaUTIL, napomene, jogaCas);
       
            priznanica.getListaStavki().add(stavkaPriznanice);
            
        }
        return priznanica;
    }

    public int getIdPriznanica() {
        return idPriznanica;
    }

    public void setIdPriznanica(int idPriznanica) {
        this.idPriznanica = idPriznanica;
    }

    public Date getDatumIzdavanja() {
        return datumIzdavanja;
    }

    public void setDatumIzdavanja(Date datumIzdavanja) {
        this.datumIzdavanja = datumIzdavanja;
    }

    public int getPopust() {
        return popust;
    }

    public void setPopust(int popust) {
        this.popust = popust;
    }

    public int getUkupanIznos() {
        return ukupanIznos;
    }

    public void setUkupanIznos(int ukupanIznos) {
        this.ukupanIznos = ukupanIznos;
    }

    public Instruktor getInstruktor() {
        return instruktor;
    }

    public void setInstruktor(Instruktor instruktor) {
        this.instruktor = instruktor;
    }

    public Polaznik getPolaznik() {
        return polaznik;
    }

    public void setPolaznik(Polaznik polaznik) {
        this.polaznik = polaznik;
    }

    public List<StavkaPriznanice> getListaStavki() {
        return listaStavki;
    }

    public void setListaStavki(List<StavkaPriznanice> listaStavki) {
        this.listaStavki = listaStavki;
    }

    @Override
    public int hashCode() {
        int hash = 7;
        hash = 41 * hash + this.idPriznanica;
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Priznanica other = (Priznanica) obj;
        return this.idPriznanica == other.idPriznanica;
    }

    
    
}
