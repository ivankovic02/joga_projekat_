/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package domen;

import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

/**
 *
 * @author Kristina
 */
public class Sertifikat implements DomainObject{
    private int idSertifikat;
    private String naziv;
    private String jogaAkademija;

    public Sertifikat() {
    }

    public Sertifikat(int idSertifikat, String naziv, String jogaAkademija) {
        this.idSertifikat = idSertifikat;
        this.naziv = naziv;
        this.jogaAkademija = jogaAkademija;
    }

    @Override
    public String toString() {
        return naziv + ", izdat od: " + jogaAkademija; 
    }

    public int getIdSertifikat() {
        return idSertifikat;
    }

    public void setIdSertifikat(int idSertifikat) {
        this.idSertifikat = idSertifikat;
    }

    public String getNaziv() {
        return naziv;
    }

    public void setNaziv(String naziv) {
        this.naziv = naziv;
    }

    public String getJogaAkademija() {
        return jogaAkademija;
    }

    public void setJogaAkademija(String jogaAkademija) {
        this.jogaAkademija = jogaAkademija;
    }

    @Override
    public String vratiUpitZaSve() {
        return "SELECT * FROM sertifikat";
    }

    @Override
    public String vratiUpitZaPretragu(Object parametarPretrage) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public List<DomainObject> napraviListuSvih(ResultSet rs) throws Exception {
        List<DomainObject> lista = new ArrayList<>();
        while(rs.next()){
            int idSertifikat = rs.getInt(1);
            String naziv = rs.getString(2);
            String jogaAkademija = rs.getString(3);
            Sertifikat sertifikat = new Sertifikat(idSertifikat, naziv, jogaAkademija);
            lista.add(sertifikat);
        }
        return lista;
    }

    @Override
    public String vratiUpitZaInsert() {
        return "INSERT INTO sertifikat(naziv, jogaAkademija) VALUES ('" + naziv + "', '" + jogaAkademija + "')";
    }

    @Override
    public void podesiGenerisaniId(int generisaniId) {
       idSertifikat = generisaniId;
    }

    @Override
    public String vratiUpitZaUpdate() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public String vratiUpitZaDelete() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public String vratiUpitZaJednog() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public DomainObject napraviJednog(ResultSet rs) throws Exception {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
}
