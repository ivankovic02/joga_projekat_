/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package domen;

import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

/**
 *
 * @author Kristina
 */
public class JogaCas implements DomainObject{
    
    private int idJogaCas;
    private String opisCasa;
    private int trajanje;
    private int cena;

    public JogaCas() {
    }

    public JogaCas(int idJogaCas, String opisCasa, int trajanje, int cena) {
        this.idJogaCas = idJogaCas;
        this.opisCasa = opisCasa;
        this.trajanje = trajanje;
        this.cena = cena;
    }

    @Override
    public String toString() {
        return opisCasa + " - " + trajanje + "min - " + cena + "rsd";
    }

    public int getIdJogaCas() {
        return idJogaCas;
    }

    public void setIdJogaCas(int idJogaCas) {
        this.idJogaCas = idJogaCas;
    }

    public String getOpisCasa() {
        return opisCasa;
    }

    public void setOpisCasa(String opisCasa) {
        this.opisCasa = opisCasa;
    }

    public int getTrajanje() {
        return trajanje;
    }

    public void setTrajanje(int trajanje) {
        this.trajanje = trajanje;
    }

    public int getCena() {
        return cena;
    }

    public void setCena(int cena) {
        this.cena = cena;
    }
   
    @Override
    public String vratiUpitZaSve() {
        return "SELECT * FROM jogacas";  
    }

    @Override
    public String vratiUpitZaPretragu(Object parametarPretrage) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public List<DomainObject> napraviListuSvih(ResultSet rs) throws Exception {
        List<DomainObject> lista = new ArrayList<>();
        while(rs.next()){
            int idJogaCas = rs.getInt(1);
            String opisCasa = rs.getString(2);
            int trajanje = rs.getInt(3);
            int cena = rs.getInt(4);
            JogaCas jogaCas = new JogaCas(idJogaCas, opisCasa, trajanje, cena);
            lista.add(jogaCas);
        }
        return lista;
    }

    @Override
    public String vratiUpitZaInsert() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public void podesiGenerisaniId(int generisaniId) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public String vratiUpitZaUpdate() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public String vratiUpitZaDelete() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public String vratiUpitZaJednog() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public DomainObject napraviJednog(ResultSet rs) throws Exception {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
    
}
