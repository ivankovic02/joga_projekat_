/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package domen;

import java.sql.ResultSet;
import java.util.Date;
import java.util.List;

/**
 *
 * @author Kristina
 */
public class StavkaPriznanice implements DomainObject{
    
    private Priznanica priznanica;
    private int rb;
    private int brojCasova;
    private int cena; //cena jednog casa
    private int iznosStavke; //ukupan iznos stavke <- cena * brojCasova
    private Date datumPocetka;
    private Date datumZavrsetka;
    private String napomene;
    private JogaCas jogaCas;

    public StavkaPriznanice() {
    }

    public StavkaPriznanice(Priznanica priznanica, int rb, int brojCasova, int cena, int iznosStavke, Date datumPocetka, Date datumZavrsetka, String napomene, JogaCas jogaCas) {
        this.priznanica = priznanica;
        this.rb = rb;
        this.brojCasova = brojCasova;
        this.cena = cena;
        this.iznosStavke = iznosStavke;
        this.datumPocetka = datumPocetka;
        this.datumZavrsetka = datumZavrsetka;
        this.napomene = napomene;
        this.jogaCas = jogaCas;
    }

    public Priznanica getPriznanica() {
        return priznanica;
    }

    public void setPriznanica(Priznanica priznanica) {
        this.priznanica = priznanica;
    }

    public int getRb() {
        return rb;
    }

    public void setRb(int rb) {
        this.rb = rb;
    }

    public int getBrojCasova() {
        return brojCasova;
    }

    public void setBrojCasova(int brojCasova) {
        this.brojCasova = brojCasova;
    }

    public int getCena() {
        return cena;
    }

    public void setCena(int cena) {
        this.cena = cena;
    }

    public int getIznosStavke() {
        return iznosStavke;
    }

    public void setIznosStavke(int iznosStavke) {
        this.iznosStavke = iznosStavke;
    }

    public Date getDatumPocetka() {
        return datumPocetka;
    }

    public void setDatumPocetka(Date datumPocetka) {
        this.datumPocetka = datumPocetka;
    }

    public Date getDatumZavrsetka() {
        return datumZavrsetka;
    }

    public void setDatumZavrsetka(Date datumZavrsetka) {
        this.datumZavrsetka = datumZavrsetka;
    }

    public String getNapomene() {
        return napomene;
    }

    public void setNapomene(String napomene) {
        this.napomene = napomene;
    }

    public JogaCas getJogaCas() {
        return jogaCas;
    }

    public void setJogaCas(JogaCas jogaCas) {
        this.jogaCas = jogaCas;
    }

    @Override
    public String vratiUpitZaSve() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public String vratiUpitZaPretragu(Object parametarPretrage) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public List<DomainObject> napraviListuSvih(ResultSet rs) throws Exception {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public String vratiUpitZaInsert() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public void podesiGenerisaniId(int generisaniId) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public String vratiUpitZaUpdate() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public String vratiUpitZaDelete() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public String vratiUpitZaJednog() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public DomainObject napraviJednog(ResultSet rs) throws Exception {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
    
}
