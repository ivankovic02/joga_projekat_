/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package domen;

import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Kristina
 */
public class Instruktor implements DomainObject{
    private int idInstruktor;
    private String ime;
    private String prezime;
    private String brojTelefona;
    private String email;
    private String sifra;

    public Instruktor() {
    }

    public Instruktor(int idInstruktor, String ime, String prezime, String brojTelefona, String email, String sifra) {
        this.idInstruktor = idInstruktor;
        this.ime = ime;
        this.prezime = prezime;
        this.brojTelefona = brojTelefona;
        this.email = email;
        this.sifra = sifra;
    }

    @Override
    public String toString() {
        return ime + " " + prezime;
    }

    public int getIdInstruktor() {
        return idInstruktor;
    }

    public void setIdInstruktor(int idInstruktor) {
        this.idInstruktor = idInstruktor;
    }

    public String getIme() {
        return ime;
    }

    public void setIme(String ime) {
        this.ime = ime;
    }

    public String getPrezime() {
        return prezime;
    }

    public void setPrezime(String prezime) {
        this.prezime = prezime;
    }

    public String getBrojTelefona() {
        return brojTelefona;
    }

    public void setBrojTelefona(String brojTelefona) {
        this.brojTelefona = brojTelefona;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getSifra() {
        return sifra;
    }

    public void setSifra(String sifra) {
        this.sifra = sifra;
    }

    @Override
    public String vratiUpitZaSve() {
        return "SELECT * FROM instruktor";
    }

    @Override
    public String vratiUpitZaPretragu(Object parametarPretrage) {
        return "SELECT * FROM instruktor WHERE email = '" + parametarPretrage + "'";
    }

    @Override
    public List<DomainObject> napraviListuSvih(ResultSet rs) throws Exception {
        List<DomainObject> lista = new ArrayList<>();
        while(rs.next()){
            int idInstruktor = rs.getInt("idInstruktor");
            String ime = rs.getString("ime");
            String prezime = rs.getString("prezime");
            String brojTelefona = rs.getString("brojTelefona");
            String email = rs.getString("email");
            String sifra = rs.getString("sifra");
            Instruktor instruktor = new Instruktor(idInstruktor, ime, prezime, brojTelefona, email, sifra);
            lista.add(instruktor);
        }
        return lista;
    }

    @Override
    public String vratiUpitZaInsert() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public void podesiGenerisaniId(int generisaniId) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public String vratiUpitZaUpdate() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public String vratiUpitZaDelete() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public String vratiUpitZaJednog() {
        //return "SELECT * FROM instruktor JOIN instruktorsertifikat ON instruktor.idInstruktor = instruktorsertifikat.idInstruktor JOIN sertifikat ON instruktorsertifikat.idSertifikat = sertifikat.idSertifikat WHERE instruktor.idInstruktor = " + idInstruktor;
        return "SELECT * FROM instruktor WHERE idInstruktor = " + idInstruktor; //ovo treba
    }

    @Override
    public DomainObject napraviJednog(ResultSet rs) throws Exception {
        Instruktor instruktor = null;
        if (rs.next()) {
            int idInstruktor = rs.getInt(1);
            String ime = rs.getString(2);
            String prezime = rs.getString(3);
            String brojTelefona = rs.getString(4);
            String email = rs.getString(5);
            String sifra = rs.getString(6);
            instruktor = new Instruktor(idInstruktor, ime, prezime, brojTelefona, email, sifra);
        }
        return instruktor;
    }
    
    
}
