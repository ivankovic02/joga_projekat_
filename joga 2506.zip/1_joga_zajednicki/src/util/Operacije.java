/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package util;

/**
 *
 * @author Kristina
 */
public interface Operacije {
    public static final int LOGIN = 1;
    public static final int VRATI_SVE_JOGA_CASOVE = 3;
    public static final int VRATI_SVE_KATEGORIJE_POLAZNIKA = 4;
    public static final int ZAPAMTI_POLAZNIKA = 5;
    public static final int PROMENI_POLAZNIKA = 6;
    public static final int VRATI_SVE_INSTRUKTORSERTIFIKAT = 7;
    public static final int KREIRAJ_POLAZNIKA = 8;
    public static final int VRATI_SVE_POLAZNIKE = 9;
    public static final int PRETRAZI_POLAZNIKE = 10;
    public static final int PRETRAZI_POLAZNIKA = 19;
    public static final int OBRISI_POLAZNIKA = 11;
    public static final int UBACI_SERTIFIKAT = 12;
    public static final int VRATI_SVE_INSTRUKTORE = 13;
    public static final int PRETRAZI_PRIZNANICE = 14;
    public static final int PRETRAZI_PRIZNANICU = 15;
    public static final int ZAPAMTI_PRIZNANICU = 17;
    public static final int PROMENI_PRIZNANICU = 18;
}
