/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package forme;

import domen.StavkaPriznanice;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;
import javax.swing.table.AbstractTableModel;

/**
 *
 * @author Kristina
 */
public class TableModelStavkePriznanice extends AbstractTableModel{

    private List<StavkaPriznanice> lista;
    private String[] kolone = new String[]{"RB","Joga cas","Trajanje casa","Cena casa","Broj casova","Ukupan iznos","Datum pocetka","Datum zavrsetka","Napomena"};

    public TableModelStavkePriznanice(List<StavkaPriznanice> lista) {
        this.lista = lista;
    }
 
    @Override
    public int getRowCount() {
        return lista.size();
    }

    @Override
    public int getColumnCount() {
        return kolone.length;
    }

    @Override
    public Object getValueAt(int rowIndex, int columnIndex) {
        StavkaPriznanice stavka = lista.get(rowIndex);
        switch(columnIndex){
            case 0:
                return stavka.getRb();
            case 1:
                return stavka.getJogaCas().getOpisCasa();
            case 2:
                return stavka.getJogaCas().getTrajanje();
            case 3:
                return stavka.getCena();
            case 4:
                return stavka.getBrojCasova();
            case 5:
                return stavka.getIznosStavke();
            case 6:
                SimpleDateFormat sdf = new SimpleDateFormat("dd.MM.yyyy");
                String datumPocetka = sdf.format(stavka.getDatumPocetka());
                return datumPocetka;
            case 7:
                SimpleDateFormat sdf1 = new SimpleDateFormat("dd.MM.yyyy");
                String datumZavrsetka = sdf1.format(stavka.getDatumZavrsetka());
                return datumZavrsetka;
            case 8:
                return stavka.getNapomene();
            default:
                return "";
        }
    }

    @Override
    public String getColumnName(int column) {
        return kolone[column];
    }

    public List<StavkaPriznanice> getLista() {
        return lista;
    }

    public void setLista(List<StavkaPriznanice> lista) {
        this.lista = lista;
    }

    void dodajStavku(StavkaPriznanice stavkaPriznanice) {
        lista.add(stavkaPriznanice);
        fireTableDataChanged();
    }

    void obrisiRed(int red) {
        lista.remove(red);
        
        for (int i = 0; i < lista.size(); i++) {
            lista.get(i).setRb(i + 1);
        }
        
        fireTableDataChanged();
    }

    public int getUkupanIznosPriznanice() {
        int suma = 0;

        for (StavkaPriznanice s : lista) {
            suma += s.getIznosStavke();
        }

        return suma;
    }
}
