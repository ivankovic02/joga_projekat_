/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package so.polaznik;

import dbb.DBBroker;
import domen.Polaznik;
import java.util.List;
import so.ApstraktnaSistemskaOperacija;

/**
 *
 * @author Kristina
 */
public class SOPromeniPolaznika extends ApstraktnaSistemskaOperacija{

    @Override
    protected void validirajPodatak(Object podatak) throws Exception {
        if(!(podatak instanceof Polaznik)) throw new Exception("Prosledjeni objekat nije tipa Polaznik");
        
        Polaznik polaznik = (Polaznik) podatak;
        List<Polaznik> lista = (List<Polaznik>)(List<?>)DBBroker.getInstanca().vratiSve(polaznik);
        
        for (Polaznik p : lista) {
            if(p.getIdPolaznik() != polaznik.getIdPolaznik() && p.getEmail().equalsIgnoreCase(polaznik.getEmail()))
                throw new Exception("Vec postoji polaznik sa prosledjenom e-mail adresom");
        }
    }

    @Override
    protected Object izvrsiOperaciju(Object podatak) throws Exception {
        Polaznik polaznik = (Polaznik) podatak;
        DBBroker.getInstanca().promeni(polaznik);
        return polaznik;
    }
    
}
