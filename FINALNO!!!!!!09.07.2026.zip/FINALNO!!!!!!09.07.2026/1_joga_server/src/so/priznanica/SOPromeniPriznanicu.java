/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package so.priznanica;

import dbb.DBBroker;
import domen.Priznanica;
import domen.StavkaPriznanice;
import so.ApstraktnaSistemskaOperacija;

/**
 *
 * @author Kristina
 */
public class SOPromeniPriznanicu extends ApstraktnaSistemskaOperacija{

    @Override
    protected void validirajPodatak(Object podatak) throws Exception {
        if(!(podatak instanceof Priznanica)) throw new Exception("Prosledjeni objekat nije tipa Priznanica");
    }

    @Override
    protected Object izvrsiOperaciju(Object podatak) throws Exception {
        Priznanica priznanicaZaPromenu = (Priznanica) podatak;
        DBBroker.getInstanca().promeni(priznanicaZaPromenu);
        
        Priznanica priznanicaIzBaze = (Priznanica) DBBroker.getInstanca().pretraziJednog(priznanicaZaPromenu);
        
        for (StavkaPriznanice novaStavka: priznanicaZaPromenu.getListaStavki()){
            if(priznanicaIzBaze.getListaStavki().contains(novaStavka)){
                DBBroker.getInstanca().promeni(novaStavka); //update, promeni
            }
            else DBBroker.getInstanca().kreiraj(novaStavka); //kreiraj novu sa ovim vrednostima
        }
        
        for (StavkaPriznanice staraStavka: priznanicaIzBaze.getListaStavki()){
            if( !(priznanicaZaPromenu.getListaStavki().contains(staraStavka)) ){
                DBBroker.getInstanca().obrisi(staraStavka);
            }
        }
        
        return priznanicaZaPromenu;
    }
    
}
