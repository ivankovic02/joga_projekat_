/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controller;

import dbb.DBBroker;
import domen.Instruktor;
import domen.InstruktorSertifikat;
import domen.JogaCas;
import domen.KategorijaPolaznika;
import domen.Polaznik;
import domen.Priznanica;
import domen.Sertifikat;
import java.util.List;
import so.instruktor.SOLogin;
import so.instruktor.SOVratiSveInstruktore;
import so.instruktorsertifikat.SOVratiSveInstruktorSertifikat;
import so.jogacas.SOVratiSveJogaCasove;
import so.kategorijapolaznika.SOVratiSveKategorijePolaznika;
import so.polaznik.SOPromeniPolaznika;
import so.polaznik.SOKreirajPolaznika;
import so.polaznik.SOObrisiPolaznika;
import so.polaznik.SOPretraziPolaznika;
import so.polaznik.SOPretraziPolaznike;
import so.polaznik.SOVratiSvePolaznike;
import so.priznanica.SOKreirajPriznanicu;
import so.priznanica.SOPretraziPriznanice;
import so.priznanica.SOPretraziPriznanicu;
import so.priznanica.SOPromeniPriznanicu;
import so.priznanica.SOVratiSvePriznanice;
import so.sertifikat.SOUbaciSertifikat;

/**
 *
 * @author Kristina
 */
public class ServerController {
    private static ServerController instanca;

    public ServerController() {
    }

    public static ServerController getInstanca() {
        if(instanca == null) instanca = new ServerController();
        return instanca;
    }

    public Instruktor login(Instruktor instruktor) throws Exception {
        SOLogin soLogin = new SOLogin();
        return (Instruktor) soLogin.izvrsi(instruktor);
    }
    
    public List<InstruktorSertifikat> vratiSveInstruktorSertifikat() throws Exception {
        SOVratiSveInstruktorSertifikat so = new SOVratiSveInstruktorSertifikat();
        return (List<InstruktorSertifikat>) so.izvrsi(null);
    }

    public List<JogaCas> vratiSveJogaCasove() throws Exception {
        SOVratiSveJogaCasove so = new SOVratiSveJogaCasove();
        return (List<JogaCas>) so.izvrsi(null);
    }

    public List<KategorijaPolaznika> vratiSveKategorijePolaznika() throws Exception {
        SOVratiSveKategorijePolaznika so = new SOVratiSveKategorijePolaznika();
        return (List<KategorijaPolaznika>) so.izvrsi(null);
    }

    /*public void zapamtiPolaznika(Polaznik polaznik) throws Exception {
        SOKreirajPolaznika so = new SOKreirajPolaznika();
        so.izvrsi(polaznik);
    }*/

    public void promeniPolaznika(Polaznik polaznik) throws Exception {
        SOPromeniPolaznika so = new SOPromeniPolaznika();
        so.izvrsi(polaznik);
    }

    public Polaznik kreirajPolaznika() throws Exception {
        SOKreirajPolaznika so = new SOKreirajPolaznika();
        return (Polaznik) so.izvrsi(null);
    }

    public List<Polaznik> vratiSvePolaznike() throws Exception {
        SOVratiSvePolaznike so = new SOVratiSvePolaznike();
        return (List<Polaznik>) so.izvrsi(new Polaznik());
    }

    public List<Polaznik> pretraziPolaznike(Object parametar) throws Exception {
        SOPretraziPolaznike so = new SOPretraziPolaznike();
        return (List<Polaznik>) so.izvrsi(parametar);
    }

    public void obrisiPolaznika(Polaznik polaznik) throws Exception {
        SOObrisiPolaznika so = new SOObrisiPolaznika();
        so.izvrsi(polaznik);
    }

    public void ubaciSertifikat(Sertifikat sertifikat) throws Exception {
        SOUbaciSertifikat so = new SOUbaciSertifikat();
        so.izvrsi(sertifikat);
    }

    public List<Instruktor> vratiSveInstruktore() throws Exception {
        SOVratiSveInstruktore so = new SOVratiSveInstruktore();
        return (List<Instruktor>) so.izvrsi(new Instruktor());
    }

    public List<Priznanica> pretraziPriznanice(Object parametar) throws Exception {
        SOPretraziPriznanice so = new SOPretraziPriznanice();
        return (List<Priznanica>) so.izvrsi(parametar);
    }

    public Priznanica pretraziPriznanicu(Priznanica priznanica) throws Exception {
        SOPretraziPriznanicu so = new SOPretraziPriznanicu();
        return (Priznanica) so.izvrsi(priznanica);
    }

    public Polaznik pretraziPolaznika(Polaznik polaznik) throws Exception {
        SOPretraziPolaznika so = new SOPretraziPolaznika();
        return (Polaznik) so.izvrsi(polaznik);
    }

    public Priznanica kreirajPriznanicu() throws Exception {
        SOKreirajPriznanicu so = new SOKreirajPriznanicu();
        return (Priznanica) so.izvrsi(null);
    }

    public void promeniPriznanicu(Priznanica priznanica) throws Exception {
        SOPromeniPriznanicu so = new SOPromeniPriznanicu();
        so.izvrsi(priznanica);
    }

    public List<Priznanica> vratiSvePriznanice() throws Exception {
        SOVratiSvePriznanice so = new SOVratiSvePriznanice();
        return (List<Priznanica>) so.izvrsi(null);
    }

  
}
