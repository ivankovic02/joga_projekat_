/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package niti;

import controller.ServerController;
import domen.Instruktor;
import domen.InstruktorSertifikat;
import domen.JogaCas;
import domen.KategorijaPolaznika;
import domen.Polaznik;
import domen.Priznanica;
import domen.Sertifikat;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;
import java.util.List;
import util.Odgovor;
import util.Operacije;
import util.Zahtev;

/**
 *
 * @author Kristina
 */
public class KlijentNit extends Thread{
    private Socket socket;

    public KlijentNit() {
    }

    public KlijentNit(Socket socket) {
        this.socket = socket;
    }

    public Socket getSocket() {
        return socket;
    }

    public void setSocket(Socket socket) {
        this.socket = socket;
    }

    @Override
    public void run() {
        while(true){
            try {
                ObjectInputStream in = new ObjectInputStream(socket.getInputStream());
                Zahtev zahtev = (Zahtev) in.readObject();
                
                Odgovor odgovor = obradiZahtev(zahtev);
                ObjectOutputStream out = new ObjectOutputStream(socket.getOutputStream());
                out.writeObject(odgovor);
                
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        }
    }
    
    public void zaustaviNit() {
        try{
            socket.close();
        }catch(Exception ex){
            ex.printStackTrace();
        }
    }

    private Odgovor obradiZahtev(Zahtev zahtev) {
        int operacija = zahtev.getOperacija();
        Odgovor odgovor = new Odgovor();
        
        try {
            switch (operacija) {
                case Operacije.LOGIN:
                    Instruktor ulogovani = ServerController.getInstanca().login((Instruktor) zahtev.getPodatak());
                    odgovor.setPodatak(ulogovani);
                    break;
                    
                case Operacije.VRATI_SVE_JOGA_CASOVE:
                    List<JogaCas> casovi = ServerController.getInstanca().vratiSveJogaCasove();
                    odgovor.setPodatak(casovi);
                    break;
                    
                case Operacije.VRATI_SVE_KATEGORIJE_POLAZNIKA:
                    List<KategorijaPolaznika> kategorije = ServerController.getInstanca().vratiSveKategorijePolaznika();
                    odgovor.setPodatak(kategorije);
                    break;
                    
                /*case Operacije.ZAPAMTI_POLAZNIKA:
                    ServerController.getInstanca().zapamtiPolaznika((Polaznik) zahtev.getPodatak());
                    break;*/
                    
                case Operacije.PROMENI_POLAZNIKA:
                    ServerController.getInstanca().promeniPolaznika((Polaznik) zahtev.getPodatak());
                    break;
                    
                case Operacije.VRATI_SVE_INSTRUKTORSERTIFIKAT:
                    List<InstruktorSertifikat> lista = ServerController.getInstanca().vratiSveInstruktorSertifikat();
                    odgovor.setPodatak(lista);
                    break;
                    
                case Operacije.KREIRAJ_POLAZNIKA:
                    Polaznik kreirani = ServerController.getInstanca().kreirajPolaznika();
                    odgovor.setPodatak(kreirani);
                    break;
                    
                case Operacije.VRATI_SVE_POLAZNIKE:
                    List<Polaznik> lista1 = ServerController.getInstanca().vratiSvePolaznike();
                    odgovor.setPodatak(lista1);
                    break;
                    
                case Operacije.PRETRAZI_POLAZNIKE:
                    List<Polaznik> lista2 = ServerController.getInstanca().pretraziPolaznike(zahtev.getPodatak());
                    odgovor.setPodatak(lista2);
                    break;
                    
                case Operacije.OBRISI_POLAZNIKA:
                    ServerController.getInstanca().obrisiPolaznika((Polaznik) zahtev.getPodatak());
                    break;
                    
                case Operacije.UBACI_SERTIFIKAT:
                    ServerController.getInstanca().ubaciSertifikat((Sertifikat) zahtev.getPodatak());
                    break;
                    
                case Operacije.VRATI_SVE_INSTRUKTORE:
                    List<Instruktor> lista3 = ServerController.getInstanca().vratiSveInstruktore();
                    odgovor.setPodatak(lista3);
                    break;
                    
                case Operacije.PRETRAZI_PRIZNANICE:
                    Object podatak = zahtev.getPodatak();
                    if (podatak instanceof java.util.Date) {
                        List<Priznanica> lista4 = ServerController.getInstanca().pretraziPriznanice((java.util.Date) podatak);
                        odgovor.setPodatak(lista4);
                        break;
                    } else if (podatak instanceof Polaznik) {
                        List<Priznanica> lista5 = ServerController.getInstanca().pretraziPriznanice((Polaznik) podatak);
                        odgovor.setPodatak(lista5);
                        break;
                    } else {
                        List<Priznanica> lista6 = ServerController.getInstanca().pretraziPriznanice((Instruktor) podatak);
                        odgovor.setPodatak(lista6);
                        break;
                    }
                    
                case Operacije.PRETRAZI_PRIZNANICU:
                    Priznanica priznanica = ServerController.getInstanca().pretraziPriznanicu((Priznanica) zahtev.getPodatak());
                    odgovor.setPodatak(priznanica);
                    break;
                    
                case Operacije.PRETRAZI_POLAZNIKA:
                    Polaznik polaznik = ServerController.getInstanca().pretraziPolaznika((Polaznik) zahtev.getPodatak());
                    odgovor.setPodatak(polaznik);
                    break;
                    
                case Operacije.KREIRAJ_PRIZNANICU:
                    Priznanica kreirana = ServerController.getInstanca().kreirajPriznanicu();
                    odgovor.setPodatak(kreirana);
                    break;
                    
                case Operacije.PROMENI_PRIZNANICU:
                    ServerController.getInstanca().promeniPriznanicu((Priznanica) zahtev.getPodatak());
                    break;
                    
                case Operacije.VRATI_SVE_PRIZNANICE:
                    List<Priznanica> lista7 = ServerController.getInstanca().vratiSvePriznanice();
                    odgovor.setPodatak(lista7);
                    break;
            }
        } catch (Exception ex) {
            ex.printStackTrace();
            odgovor.setGreska(ex);
        }
        
        return odgovor;
    }
    
}
