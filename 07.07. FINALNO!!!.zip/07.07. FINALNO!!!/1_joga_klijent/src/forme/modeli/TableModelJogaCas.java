/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package forme.modeli;

import domen.JogaCas;
import java.util.ArrayList;
import java.util.List;
import javax.swing.table.AbstractTableModel;

/**
 *
 * @author Kristina
 */
public class TableModelJogaCas extends AbstractTableModel {
    private List<JogaCas> lista = new ArrayList<>();
    private String[] kolone = new String[]{"Opis casa", "Trajanje", "Cena"};

    public TableModelJogaCas(List<JogaCas> lista) {
        this.lista = lista;
    }
    
    @Override
    public int getRowCount() {
        return lista.size();
    }

    @Override
    public int getColumnCount() {
        return kolone.length;
    }

    @Override
    public Object getValueAt(int rowIndex, int columnIndex) {
        JogaCas jogaCas = lista.get(rowIndex);
        switch(columnIndex){
            case 0:
                return jogaCas.getOpisCasa();
            case 1:
                return jogaCas.getTrajanje();
            case 2:
                return jogaCas.getCena();
            default:
                return "";
        }
    }

    @Override
    public String getColumnName(int column) {
        return kolone[column];
    }
    
    
    
}
