/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package forme.modeli;

import domen.StavkaPriznanice;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import javax.swing.table.AbstractTableModel;

/**
 *
 * @author Kristina
 */
public class TableModelStavkePriznanice extends AbstractTableModel{

    private List<StavkaPriznanice> lista;
    private String[] kolone = new String[]{"RB", "Joga cas", "Trajanje casa", "Cena casa", "Broj casova", "Ukupan iznos", "Datum pocetka", "Datum zavrsetka", "Napomena"};
    private int izmenaRed = -1;
    private int izmenaKolona = -1;
    
    public TableModelStavkePriznanice(List<StavkaPriznanice> lista) {
        this.lista = lista;
        fireTableDataChanged();
    }
 
    @Override
    public int getRowCount() {
        return lista.size();
    }

    @Override
    public int getColumnCount() {
        return kolone.length;
    }

    public void omoguciIzmenu(int row, int column) {
        izmenaRed = row;
        izmenaKolona = column;
    }
  
    public void zabraniIzmenu() {
        izmenaRed = -1;
        izmenaKolona = -1;
    }
    
    @Override
    public boolean isCellEditable(int row, int column) {

        if (row != izmenaRed || column != izmenaKolona) {
            return false;
        }

        return column == 4
                || column == 6
                || column == 7
                || column == 8;
    }

    @Override
    public Object getValueAt(int rowIndex, int columnIndex) {
        StavkaPriznanice stavka = lista.get(rowIndex);
        switch(columnIndex){
            case 0:
                return stavka.getRb();
            case 1:
                return stavka.getJogaCas().getOpisCasa();
            case 2:
                return stavka.getJogaCas().getTrajanje();
            case 3:
                return stavka.getCena();
            case 4:
                return stavka.getBrojCasova();
            case 5:
                return stavka.getIznosStavke();
            case 6:
                SimpleDateFormat sdf = new SimpleDateFormat("dd.MM.yyyy");
                String datumPocetka = sdf.format(stavka.getDatumPocetka());
                return datumPocetka;
            case 7:
                SimpleDateFormat sdf1 = new SimpleDateFormat("dd.MM.yyyy");
                String datumZavrsetka = sdf1.format(stavka.getDatumZavrsetka());
                return datumZavrsetka;
            case 8:
                return stavka.getNapomene();
            default:
                return "";
        }
    }
    
    @Override
    public void setValueAt(Object value, int row, int column) {
        StavkaPriznanice stavka = lista.get(row);
        SimpleDateFormat sdf = new SimpleDateFormat("dd.MM.yyyy");
        
        switch (column) {
            case 4:
                stavka.setBrojCasova(Integer.parseInt(value.toString()));
                stavka.setIznosStavke(
                stavka.getBrojCasova() * stavka.getCena());
                fireTableCellUpdated(row, 5);
                break;
                
            case 6:

            {
                try {
                    stavka.setDatumPocetka(sdf.parse((String) value));
                } catch (ParseException ex) {
                    Logger.getLogger(TableModelStavkePriznanice.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
            break;

            case 7:
            {
                try {
                    stavka.setDatumZavrsetka(sdf.parse((String) value));
                } catch (ParseException ex) {
                    Logger.getLogger(TableModelStavkePriznanice.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
                break;

            case 8:
                stavka.setNapomene(value.toString());
                break;
        }
        zabraniIzmenu();
        fireTableCellUpdated(row, column);
    }

    @Override
    public String getColumnName(int column) {
        return kolone[column];
    }

    public List<StavkaPriznanice> getLista() {
        return lista;
    }

    public void setLista(List<StavkaPriznanice> lista) {
        this.lista = lista;
        fireTableDataChanged();
    }

    public void dodajStavku(StavkaPriznanice stavkaPriznanice) {
        for (StavkaPriznanice postojeca : lista) {

            if (postojeca.getJogaCas().equals(stavkaPriznanice.getJogaCas())
                    && postojeca.getCena() == stavkaPriznanice.getCena()
                    && postojeca.getDatumPocetka().equals(stavkaPriznanice.getDatumPocetka())
                    && postojeca.getDatumZavrsetka().equals(stavkaPriznanice.getDatumZavrsetka())
                    && postojeca.getNapomene().equals(stavkaPriznanice.getNapomene())) {

                // poveca broj casova
                postojeca.setBrojCasova(
                        postojeca.getBrojCasova() + stavkaPriznanice.getBrojCasova());

                // izracuna novi iznos stavke
                postojeca.setIznosStavke(
                        postojeca.getBrojCasova() * postojeca.getCena());

                fireTableDataChanged();
                return;
            }
        }

        //ako ta ista stavka NE postoji vec u tabeli
        lista.add(stavkaPriznanice);
        fireTableDataChanged();
    }

    public void obrisiRed(int red) {
        lista.remove(red);
        
        for (int i = 0; i < lista.size(); i++) {
            lista.get(i).setRb(i + 1);
        }
        
        fireTableDataChanged();
    }

    public int getUkupanIznosPriznanice() {
        int suma = 0;

        for (StavkaPriznanice s : lista) {
            suma += s.getIznosStavke();
        }

        return suma;
    }
}
