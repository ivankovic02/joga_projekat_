/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package forme.modeli;

import controller.ClientController;
import domen.Priznanica;
import domen.StavkaPriznanice;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;
import javax.swing.table.AbstractTableModel;

/**
 *
 * @author Kristina
 */
public class TableModelPriznanice extends AbstractTableModel{
    private List<Priznanica> lista = new ArrayList<>();
    private String[] kolone = new String[]{"ID","Datum izdavanja","Popust u %","Ukupan iznos (sa popustom)","Instruktor","Polaznik"};

    public TableModelPriznanice(List<Priznanica> lista) {
        this.lista = lista;
    }

    @Override
    public int getRowCount() {
        return lista.size();
    }

    @Override
    public int getColumnCount() {
        return kolone.length;
    }

    @Override
    public Object getValueAt(int rowIndex, int columnIndex) {
        Priznanica p = lista.get(rowIndex);
        switch(columnIndex){
            case 0:
                return p.getIdPriznanica();
            case 1:
                SimpleDateFormat sdf = new SimpleDateFormat("dd.MM.yyyy");
                String datumIzdavanja = sdf.format(p.getDatumIzdavanja());
                return datumIzdavanja;
            case 2:
                return p.getPopust();
            case 3:
                return p.getUkupanIznos()+"rsd";
            case 4:
                return p.getInstruktor();
            case 5:
                return p.getPolaznik();
            default:
                return "";
        }
    }

    @Override
    public String getColumnName(int column) {
        return kolone[column];
    }

    public List<Priznanica> getLista() {
        return lista;
    }

    public void setLista(List<Priznanica> lista) {
        this.lista = lista;
        fireTableDataChanged();
    }

    public Priznanica vratiNaIzabranomRedu(int red) {
        return lista.get(red);
    }

    
    //ipak necu ovo, ne uklapa mi se u rad programa
    /*@Override
    public void run() {
        try {
            while (true) {
                Thread.sleep(3000);
                lista = ClientController.getInstanca().vratiSvePriznanice();
                fireTableDataChanged();
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }*/

    
}
