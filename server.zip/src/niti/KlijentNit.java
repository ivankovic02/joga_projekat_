/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package niti;

import controller.ServerController;
import domen.Instruktor;
import domen.InstruktorSertifikat;
import domen.JogaCas;
import domen.KategorijaPolaznika;
import domen.Polaznik;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;
import java.util.List;
import util.Odgovor;
import util.Operacije;
import util.Zahtev;

/**
 *
 * @author Kristina
 */
public class KlijentNit extends Thread{
    private Socket socket;

    public KlijentNit() {
    }

    public KlijentNit(Socket socket) {
        this.socket = socket;
    }

    public Socket getSocket() {
        return socket;
    }

    public void setSocket(Socket socket) {
        this.socket = socket;
    }

    @Override
    public void run() {
        while(true){
            try {
                ObjectInputStream in = new ObjectInputStream(socket.getInputStream());
                Zahtev zahtev = (Zahtev) in.readObject();
                
                Odgovor odgovor = obradiZahtev(zahtev);
                ObjectOutputStream out = new ObjectOutputStream(socket.getOutputStream());
                out.writeObject(odgovor);
                
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        }
    }
    
    public void zaustaviNit() {
        try{
            socket.close();
        }catch(Exception ex){
            ex.printStackTrace();
        }
    }

    private Odgovor obradiZahtev(Zahtev zahtev) {
        int operacija = zahtev.getOperacija();
        Odgovor odgovor = new Odgovor();
        
        try {
            switch (operacija) {
                case Operacije.LOGIN:
                    Instruktor ulogovani = ServerController.getInstanca().login((Instruktor) zahtev.getPodatak());
                    odgovor.setPodatak(ulogovani);
                    break;
                    
                case Operacije.VRATI_SVE_JOGA_CASOVE:
                    List<JogaCas> casovi = ServerController.getInstanca().vratiSveJogaCasove();
                    odgovor.setPodatak(casovi);
                    break;
                    
                case Operacije.VRATI_SVE_KATEGORIJE_POLAZNIKA:
                    List<KategorijaPolaznika> kategorije = ServerController.getInstanca().vratiSveKategorijePolaznika();
                    odgovor.setPodatak(kategorije);
                    break;
                    
                case Operacije.SACUVAJ_POLAZNIKA:
                    ServerController.getInstanca().sacuvajPolaznika((Polaznik) zahtev.getPodatak());
                    break;
                    
                case Operacije.IZMENI_POLAZNIKA:
                    ServerController.getInstanca().izmeniPolaznika((Polaznik) zahtev.getPodatak());
                    break;
                    
                case Operacije.VRATI_SVE_INSTRUKTORSERTIFIKAT:
                    List<InstruktorSertifikat> lista = ServerController.getInstanca().vratiSveInstruktorSertifikat();
                    odgovor.setPodatak(lista);
                    break;
                    
                case Operacije.KREIRAJ_POLAZNIKA:
                    Polaznik kreirani = ServerController.getInstanca().kreirajPolaznika();
                    odgovor.setPodatak(kreirani);
                    break;
                    
                case Operacije.VRATI_SVE_POLAZNIKE:
                    List<Polaznik> lista1 = ServerController.getInstanca().vratiSvePolaznike();
                    odgovor.setPodatak(lista1);
                    break;
            }
        } catch (Exception ex) {
            ex.printStackTrace();
            odgovor.setGreska(ex);
        }
        
        return odgovor;
    }
    
}
