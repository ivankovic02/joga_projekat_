/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package niti;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Kristina
 */
public class ServerNit extends Thread{
    private ServerSocket serverSocket;
    private Socket socket;
    private List<KlijentNit> listaKlijenata = new ArrayList<>();

    public ServerNit() throws Exception {
        serverSocket = new ServerSocket(10000);
    }

    @Override
    public void run() {
        while(!serverSocket.isClosed()){
            try {
                socket = serverSocket.accept();
                KlijentNit klijentNit = new KlijentNit(socket);
                klijentNit.start();
                listaKlijenata.add(klijentNit);
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        }
    }
    
    public void ugasiServer(){
        try {
            for(KlijentNit klijentNit: listaKlijenata){
                klijentNit.zaustaviNit();
            }
            serverSocket.close();
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

}
