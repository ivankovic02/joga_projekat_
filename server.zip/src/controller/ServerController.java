/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controller;

import dbb.DBBroker;
import domen.Instruktor;
import domen.InstruktorSertifikat;
import domen.JogaCas;
import domen.KategorijaPolaznika;
import domen.Polaznik;
import java.util.List;
import so.instruktor.SOLogin;
import so.instruktorsertifikat.SOVratiSveInstruktorSertifikat;
import so.jogacas.SOVratiSveJogaCasove;
import so.kategorijapolaznika.SOVratiSveKategorijePolaznika;
import so.polaznik.SOPromeniPolaznika;
import so.polaznik.SOKreirajPolaznika;
import so.polaznik.SOVratiSvePolaznike;

/**
 *
 * @author Kristina
 */
public class ServerController {
    private static ServerController instanca;

    public ServerController() {
    }

    public static ServerController getInstanca() {
        if(instanca == null) instanca = new ServerController();
        return instanca;
    }

    public Instruktor login(Instruktor instruktor) throws Exception {
        SOLogin soLogin = new SOLogin();
        return (Instruktor) soLogin.izvrsi(instruktor);
    }
    
    public List<InstruktorSertifikat> vratiSveInstruktorSertifikat() throws Exception {
        SOVratiSveInstruktorSertifikat so = new SOVratiSveInstruktorSertifikat();
        return (List<InstruktorSertifikat>) so.izvrsi(null);
    }

    public List<JogaCas> vratiSveJogaCasove() throws Exception {
        SOVratiSveJogaCasove so = new SOVratiSveJogaCasove();
        return (List<JogaCas>) so.izvrsi(null);
    }

    public List<KategorijaPolaznika> vratiSveKategorijePolaznika() throws Exception {
        SOVratiSveKategorijePolaznika so = new SOVratiSveKategorijePolaznika();
        return (List<KategorijaPolaznika>) so.izvrsi(null);
    }

    public void sacuvajPolaznika(Polaznik polaznik) throws Exception {
        SOKreirajPolaznika so = new SOKreirajPolaznika();
        so.izvrsi(polaznik);
    }

    public void izmeniPolaznika(Polaznik polaznik) throws Exception {
        SOPromeniPolaznika so = new SOPromeniPolaznika();
        so.izvrsi(polaznik);
    }

    public Polaznik kreirajPolaznika() throws Exception {
        SOKreirajPolaznika so = new SOKreirajPolaznika();
        return (Polaznik) so.izvrsi(null);
    }

    public List<Polaznik> vratiSvePolaznike() throws Exception {
        SOVratiSvePolaznike so = new SOVratiSvePolaznike();
        return (List<Polaznik>) so.izvrsi(new Polaznik());
    }

  
}
