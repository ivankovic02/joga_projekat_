/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package so.jogacas;

import dbb.DBBroker;
import domen.JogaCas;
import java.util.List;
import so.ApstraktnaSistemskaOperacija;

/**
 *
 * @author Kristina
 */
public class SOVratiSveJogaCasove extends ApstraktnaSistemskaOperacija{

    @Override
    protected void validirajPodatak(Object podatak) throws Exception {
    }

    @Override
    protected Object izvrsiOperaciju(Object podatak) throws Exception {
        return (List<JogaCas>)(List<?>) DBBroker.getInstanca().vratiSve(new JogaCas());
    }
    
}
