/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package so.sertifikat;

import so.ApstraktnaSistemskaOperacija;

/**
 *
 * @author Kristina
 */
public class SOUbaciSertifikat extends ApstraktnaSistemskaOperacija{

    @Override
    protected void validirajPodatak(Object podatak) throws Exception {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    protected Object izvrsiOperaciju(Object podatak) throws Exception {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
    
}
