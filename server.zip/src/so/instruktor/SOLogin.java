/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package so.instruktor;

import dbb.DBBroker;
import domen.Instruktor;
import java.util.List;
import so.ApstraktnaSistemskaOperacija;

/**
 *
 * @author Kristina
 */
public class SOLogin extends ApstraktnaSistemskaOperacija{

    @Override
    protected void validirajPodatak(Object podatak) throws Exception {
        if(!(podatak instanceof Instruktor)) throw new Exception("Prosledjeni objekat nije instruktor");
    }

    @Override
    protected Object izvrsiOperaciju(Object podatak) throws Exception {
        Instruktor instruktor = (Instruktor) podatak;
        
        List<Instruktor> lista = (List<Instruktor>)(List<?>)DBBroker.getInstanca().pretrazi(instruktor, instruktor.getEmail());
        
        if(lista.get(0).getSifra().equals(instruktor.getSifra())) return lista.get(0);
        
        /*for(Instruktor i: lista){
            if(i.getSifra().equals(instruktor.getSifra())){
                return DBBroker.getInstanca().vratiJednog(i);
            }
        }*/
        
        throw new Exception("Pogresni kredencijali!");
    }
    
}
