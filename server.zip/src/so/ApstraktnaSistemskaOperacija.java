/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package so;

import dbb.DBBroker;

/**
 *
 * @author Kristina
 */
public abstract class ApstraktnaSistemskaOperacija {
    
    public Object izvrsi(Object podatak) throws Exception{
        try {
            DBBroker.getInstanca().otvoriKonekcijuNaBazu();
            
            validirajPodatak(podatak);
            Object rezultat = izvrsiOperaciju(podatak);
            
            DBBroker.getInstanca().commit();
            return rezultat;
            
        } catch (Exception ex) {
            DBBroker.getInstanca().rollback();
            throw ex;
        }
        finally{
            DBBroker.getInstanca().zatvoriKonekcijuNaBazu();
        }
    }

    protected abstract void validirajPodatak(Object podatak) throws Exception; 
   
    protected abstract Object izvrsiOperaciju(Object podatak) throws Exception; 
      
}
