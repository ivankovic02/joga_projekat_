/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package so.instruktorsertifikat;

import dbb.DBBroker;
import domen.InstruktorSertifikat;
import java.util.List;
import so.ApstraktnaSistemskaOperacija;

/**
 *
 * @author Kristina
 */
public class SOVratiSveInstruktorSertifikat extends ApstraktnaSistemskaOperacija{

    @Override
    protected void validirajPodatak(Object podatak) throws Exception {
    }

    @Override
    protected Object izvrsiOperaciju(Object podatak) throws Exception {
        return (List<InstruktorSertifikat>)(List<?>)DBBroker.getInstanca().vratiSve(new InstruktorSertifikat());
    }
    
}
