/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package so.kategorijapolaznika;

import dbb.DBBroker;
import domen.KategorijaPolaznika;
import so.ApstraktnaSistemskaOperacija;
import java.util.List;

/**
 *
 * @author Kristina
 */
public class SOVratiSveKategorijePolaznika extends ApstraktnaSistemskaOperacija{

    @Override
    protected void validirajPodatak(Object podatak) throws Exception {
    }

    @Override
    protected Object izvrsiOperaciju(Object podatak) throws Exception {
        return /*(List<KategorijaPolaznika>)(List<?>)*/DBBroker.getInstanca().vratiSve(new KategorijaPolaznika());
    }
    
}
